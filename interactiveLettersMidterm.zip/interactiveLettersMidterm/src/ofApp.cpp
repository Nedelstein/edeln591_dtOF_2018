#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    ofBackground(0);
//    ofSetVerticalSync(false);
    ofSetCircleResolution(100);
    
    letter.setup(currentChar);
    
    noah['n'] = Letters();
    noah['n'].setup('N');
    noah['o'] = Letters();
    noah['o'].setup('O');
    noah['a'] = Letters();
    noah['a'].setup('A');
    noah['h'] = Letters();
    noah['h'].setup('H');
    
    
    glm::vec2 posTop = glm::vec2(ofRandom(ofGetWidth()), ofRandom(0,5));
    
    ParticleSystemTop _particleSystemTop = ParticleSystemTop(posTop);
    particleSystemTop.push_back(_particleSystemTop);
    
    
    elasticForceOn = true;
    
    
}

//--------------------------------------------------------------
void ofApp::update(){
    
//    if(currentChar != ' '){
    
    
    for (int i=0; i<particleSystemTop.size(); i++){
        
        glm::vec2 force = noah[currentChar].getForce(particleSystemTop[i].pos);
        particleSystemTop[i].applyForce(force);
        particleSystemTop[i].applyDampingForce(0.2);
        particleSystemTop[i].update();
        
        if (elasticForceOn){
            particleSystemTop[i].applyElasticForce(0.3);
        }
    
        
        //particle force from top to center/////
        glm::vec2 dirTop = center - particleSystemTop[i].pos;
        float distanceTop = glm::length(dirTop);
        if(distanceTop >0){
            glm::vec2 normalizedDirTop = dirTop / distanceTop;

            attractionTop = normalizedDirTop;
        }



    }
    
//}
}

//--------------------------------------------------------------
void ofApp::draw(){

    for (int i=0; i<particleSystemTop.size(); i++){
        particleSystemTop[i].draw();
    }
    
    letter.draw();
    
    
    


}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    
    
    if (key == 'f'){
        ofToggleFullscreen();
        
    }
    
    if (key == 'n' || key == 'o' || key == 'a' || key == 'h'){
        currentChar = key;
        for (int i=0; i<particleSystemTop.size(); i++){
        particleSystemTop[i].applyForce(attractionTop);
        elasticForceOn = false;
        }
    }
    
//    if (key == 'n'){
//        for (int i=0; i<particleSystemTop.size(); i++){
//
////            letter.nDraw = true;
//
//        }
    
    
    if (key == 'o'){
        for(int i=0; i<particleSystemTop.size(); i++){
            particleSystemTop[i].applyForce(attractionTop);
            letter.oDraw = true;
            particleSystemTop[i].oForce = true;
        }
    }

    if (key == 'a'){

    }
    if (key == 'h'){

    }
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    if (key == 'n' || key == 'o' || key == 'a' || key == 'h'){
        currentChar = ' ';
        for (int i=0; i<particleSystemTop.size(); i++){
//            particleSystemTop[i].applyElasticForce(3);
            particleSystemTop[i].oForce = false;
    }
        letter.nDraw = false;
        letter.oDraw = false;
    }
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
