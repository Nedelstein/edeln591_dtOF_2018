#include "Letters.hpp"

void Letters::setup(char c) {
    letterFont.loadFont("Courier New.ttf", 500, false,false,true);
    
    ofTTFCharacter nLetter = letterFont.getCharacterAsPoints(c, true, false);
    vector<ofPolyline> nPolylines = nLetter.getOutline();
    for (int j = 0; j<nPolylines.size(); j++){
        ofPolyline outline = nPolylines[j].getResampledBySpacing(4);
        for (int k = 0; k < outline.size(); k++){
//            ofDrawCircle(outline[k],2);
            attractors.push_back(outline[k]);
           

            }
        }
    
    
    oPos.x = ofGetWidth() *0.5;
    oPos.y = ofGetHeight() *0.5;
    oRad = ofGetWidth()/4;
    
    
}

///add a get force function based on the attractor vector position and the particle position (that returns a vec2 force value)
//takes in position of particle and loops through all the attractors, calc a force between particle and that attractor and return the accumulated force. make the force of each attractor really small, or clamp the magnitude of the force vector

glm::vec2 Letters::getForce(glm::vec2 pos){
    glm::vec2 force;
    for (int i=0; i<attractors.size(); i++){
        glm::vec2 dir = attractors[i] - pos;
        float distance = glm::length(dir);
        if (distance >0 ){
            glm::vec2 norm = dir/distance;
            force += norm * 0.02;
        }
    }
}

void Letters::update(){

}

//void Letters::Ncollide(){
//
//}

    
//    for(int i=0; i<particles.size(); i++){
//        glm::vec2 delta = oPos - particles[i].pos;
//        float d = delta.x * delta.x + delta.y * delta.y;
//        float r = particles[i].radius + oRad;
//        if (d< r*r){
//            glm::vec2 dir = particles[i].pos - oPos;
//            //normalize dir/////
//            float length = glm::length(dir);
//            glm::vec2 normDir;
//            if(length !=0){
//                normDir = dir/length;
//            }
//            particles[i].applyForce(2*normDir);
//
//    }
//
//    }
//}


void Letters::draw(){
    
    for(int i=0; i<attractors.size(); i++){
        ofPushMatrix();
        ofTranslate(ofGetWidth()/2, ofGetHeight()/2);
        ofDrawCircle(attractors[i], 2);
        ofPopMatrix();
    }
}

//    if(nDraw){
////    letterN.draw();
//        vector<ofTTFCharacter> nLetter = letterFont.getStringAsPoints("N", true, false);
//        ofPushMatrix();
//        ofTranslate(ofGetWidth()/2, ofGetHeight()/2);
//        for(int i = 0; i<nLetter.size(); i++){
//            vector<ofPolyline> nPolylines = nLetter[i].getOutline();
//            for (int j = 0; j<nPolylines.size(); j++){
//                ofPolyline outline = nPolylines[j].getResampledBySpacing(4);
//                for (int k = 0; k < outline.size(); k++){
//                ofDrawCircle(outline[k],2);
//            }
//        }
//    }
//        ofPopMatrix();
    
//    if(oDraw){
//        ofPushStyle();
//        ofSetCircleResolution(100);
//        ofNoFill();
//        ofSetLineWidth(15);
//        ofDrawCircle(oPos, oRad);
//        ofPopStyle();
//    }

    
    
    
//
//    str = _str;
//
//    ofPoint startPos;
//    startPos.x =  ofGetWidth() *.5;
//    startPos.y =  ofGetHeight() * .5;
//
//}



